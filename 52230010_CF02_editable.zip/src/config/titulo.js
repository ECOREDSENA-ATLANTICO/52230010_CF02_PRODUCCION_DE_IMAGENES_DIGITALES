module.exports = 'Estrategia comunicativa en los medios publicitarios'
