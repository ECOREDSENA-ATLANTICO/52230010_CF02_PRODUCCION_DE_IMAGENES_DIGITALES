<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .titulo-principal.color-acento-contenido
      .titulo-principal__numero
        span 1
      h1 Concepto sobre medios convencionales
    .fondo.fn-1
      .row.justify-content-center.align-items-center.mb-5(data-aos="fade-left")
        .col-lg-4.col-sm-8
          figure.mb-5
            img(src='@/assets/curso/temas/tema1/img-1.png')
        .col-lg-8
          p Los medios convencionales como prensa, radio, televisión e Internet son esenciales en las campañas publicitarias por su capacidad de alcance y segmentación. La prensa ofrece contenido detallado y dirigido a audiencias específicas, ideal para anuncios informativos y locales.
          p La radio proporciona inmediatez y conexión directa con el público, siendo efectiva para campañas que buscan cercanía y repetición constante del mensaje, a través de programas en vivo y su accesibilidad en diversos contextos. 

          .cajon.color-primario.p-4.mb-4.fnd-1
            p La televisión e Internet combinan poder visual y accesibilidad global, permitiendo un impacto masivo y emocional, además de la posibilidad de interacción y medición en tiempo real, lo que las convierte en herramientas clave para campañas integrales y dinámicas. A continuación, se explican unos conceptos sobre los medios publicitarios:

      .row.justify-content-center.align-items-center.mb-5.fnd-2.p-5(data-aos="zoom-in")
        .tarjeta.p-4
          SlyderA(tipo="b")
            .row.align-items-center.justify-content-center
              .col-lg-6.col-sm-12.mb-4.mb-md-0
                h3 Prensa	
                p La publicidad en la prensa goza de alta credibilidad gracias a la segmentación de lectores y se puede adquirir por módulos o tamaños en la página del periódico. Es efectiva para campañas que requieren profundidad en la información, aprovechando la credibilidad y la permanencia del formato impreso. Además, permite segmentar el mercado por intereses, demografía y geografía, logrando un impacto focalizado y duradero en el lector. La prensa, como medio tradicional de comunicación masiva, ofrece una plataforma sólida para la publicidad. A través de los contenidos de los periódicos, se puede llegar a audiencias específicas con mensajes detallados y visualmente atractivos.
              .col-lg-6.col-sm-8
                figure
                  img(src='@/assets/curso/temas/tema1/img-2.png')
                  figcaption Fuente: (La voz de Rioba, 2012)
            .row.align-items-center.justify-content-center
              .col-lg-6.col-sm-12.mb-4.mb-md-0
                h3 Revistas	
                p Hernández (1999) afirma, que las revistas gozan de una receptividad selectiva y especializada de la audiencia, y poseen un gran poder de atracción visual por su calidad de colores e ilustraciones. La revista es un medio eficaz para la publicidad, combinando contenido editorial con anuncios visualmente impactantes. Su formato permite una presentación creativa y segmentada de los productos, captando la atención de audiencias específicas interesadas en temas relacionados. Las revistas ofrecen una experiencia de lectura prolongada, lo que aumenta la visibilidad y el impacto de los anuncios. Los formatos más importantes son la contraportada, que es un anuncio publicitario ubicado en la cubierta posterior de la revista; la doble página; una página; o emplazamientos especiales, como un póster central en el interior de la revista o un desplegable. 	 
              .col-lg-6.col-sm-8
                figure
                  img(src='@/assets/curso/temas/tema1/img-3.png') 
                  figcaption Fuente: (Behance, Sin fecha)
            .row.align-items-center.justify-content-center
              .col-lg-6.col-sm-12.mb-4.mb-md-0
                h3 Cine 	
                p El cine es una plataforma poderosa para la publicidad, ya que combina narrativa visual y emocional para captar la atención del público. La publicidad en el cine ofrece un impacto visual máximo y una segmentación adecuada de acuerdo con el público de la película. Los anuncios insertos en películas o tráilers, aprovechan el impacto de la imagen en movimiento para promover productos y marcas de manera creativa. Se utilizan formatos como los <em>spots</em> antes de la proyección de la película, para el posicionamiento de producto, en el cual se referencia el producto o servicio dentro de la narrativa de la película. Esta integración no solo enriquece la experiencia cinematográfica, sino que también maximiza el alcance y la efectividad de los mensajes publicitarios.
              .col-lg-6.col-sm-8
                figure
                  img(src='@/assets/curso/temas/tema1/img-4.png') 
                  figcaption Fuente: (whatculture.com, Sin fecha)             
            .row.align-items-center.justify-content-center
              .col-lg-6.col-sm-12.mb-4.mb-md-0
                h3 Radio 	
                p.mb-0 La radio es un medio eficaz para la publicidad, debido a su capacidad de llegar a audiencias diversas a través de la transmisión en vivo y su accesibilidad constante. La publicidad radiofónica se implementa de acuerdo con la segmentación de la audiencia, y su costo se basa en la frecuencia de emisión diaria. 
                p Esta exposición frecuente fortalece el reconocimiento de la marca y la fidelidad del consumidor, en horarios y programas específicos, maximizando la exposición. Los formatos mayormente utilizados son la cuña, basada en un mensaje pregrabado con una duración de 15 a 30 segundos, y el <em>jingle</em>, que es un anuncio cantado
              .col-lg-6.col-sm-8
                figure
                  img(src='@/assets/curso/temas/tema1/img-5.png')  
            .row.align-items-center.justify-content-center
              .col-lg-6.col-sm-12.mb-4.mb-md-0
                h3 Televisión
                p La televisión es crucial para la publicidad de productos y servicios, porque ofrece un alcance masivo y segmentado. Se caracteriza por anunciar el producto o servicio con imágenes en movimiento y efectos sonoros especiales. Su importancia radica en su capacidad para captar la atención del espectador mediante contenido visual y auditivo impactante. La publicidad se utiliza para generar reconocimiento de marca, atraer clientes y potenciar las ventas a través de anuncios bien elaborados y ubicados estratégicamente. Este medio goza de varios formatos, como el <em>spot</em> televisivo, que es un comercial de aproximadamente 30 segundos, donde se promocionan y venden los productos en la parrilla de programación.	
              .col-lg-6.col-sm-8
                figure
                  img(src='@/assets/curso/temas/tema1/img-6.png')             
            .row.align-items-center.justify-content-center
              .col-lg-6.col-sm-12.mb-4.mb-md-0
                h3 Internet	
                p.mb-0 En la era digital, el internet es una herramienta esencial para la publicidad, ofreciendo un alcance global sin precedentes. Permite a las marcas fragmentar su audiencia con precisión, personalizar mensajes y medir resultados en tiempo real, maximizando la efectividad de las campañas. Su flexibilidad y capacidad para adaptarse a nuevas tendencias lo convierten en un medio fundamental de la estrategia publicitaria moderna.
                p Los formatos de promoción en internet son los banners, videos, anuncios en redes sociales y <em>marketing</em> de contenidos, que permiten segmentar anuncios según intereses y comportamientos, para incrementar la visibilidad, atraer clientes potenciales y crear campañas dirigidas y efectivas.
              .col-lg-6.col-sm-8
                figure
                  img(src='@/assets/curso/temas/tema1/img-7.png')   
            .row.align-items-center.justify-content-center
              .col-lg-6.col-sm-12.mb-4.mb-md-0
                h3 Publicidad exterior	
                p.mb-0 La publicidad exterior es una estrategia visual que utiliza espacios públicos, como las vallas fijas o móviles; la publicidad sobre mobiliario urbano, como el "mupi", que aloja carteles publicitarios ubicados en las paradas de autobús; y la publicidad en transportes públicos, como taxis o autobuses. También se emplea la publicidad aérea, con carteleras en avionetas o zepelines (globos aerostáticos ovalados), para promover productos o servicios.
                p Su objetivo es captar la atención de un gran número de personas en su entorno cotidiano. Para lograrlo, se emplean diseños llamativos y mensajes directos, ubicados en lugares estratégicos con alto tráfico, garantizando así un amplio alcance e impacto.	 
              .col-lg-6.col-sm-8
                figure
                  img(src='@/assets/curso/temas/tema1/img-8.png')  
                  figcaption Fuente: (puntoenblanco.com)


          
</template>

<script>
export default {
  name: 'Tema1',
  components: {},
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass"></style>
